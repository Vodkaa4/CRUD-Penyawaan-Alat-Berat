<?php 
    $id = base64_decode($_GET['id']);
    $my = mysqli_query($koneksi, "SELECT * FROM alat_berat WHERE id_alatberat='$id'");
    $data = mysqli_fetch_array($my);
    $gambar = $data['gambar'];
	if (file_exists("alat_berat/gambar_alat/$gambar")){
        unlink("alat_berat/gambar_alat/$gambar");
        echo "<script>alert('Data Alat Berat Berhasil Dihapus!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=alat_berat/index'></script>";
    }else{
        echo "<script>alert('Terjadi Kesalahan Coba Ulangi!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=alat_berat/index'></script>";
    }

    $my2 = mysqli_query($koneksi, "DELETE FROM alat_berat WHERE id_alatberat='$id'");
    
 ?>