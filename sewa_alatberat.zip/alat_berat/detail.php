<?php 
$id = base64_decode($_GET['id']);
$mysql = mysqli_query($koneksi, "SELECT * FROM alat_berat WHERE id_alatberat='$id'");
$data = mysqli_fetch_array($mysql); 

?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h4 class="h3 mb-0 text-gray-800"> &nbsp;DETAIL DATA ALAT BERAT</h4>
</div>

<!-- DataTales Example -->
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">GAMBAR ALAT BERAT</h6>
                </div>
                <div class="card-body">
                   <img src="alat_berat/gambar_alat/<?php echo $data['gambar'] ?>" style="width: 300px;height: 300px;"> 
               </div>
           </div>
       </div>
       <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DATA ALAT BERAT <a class="btn btn-secondary btn-sm float-right" href="?page=alat_berat/index">Kembali</a></h6>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><center>Nama</center></th>
                                <th><center>Merk</center></th>
                                <th><center>Nopol</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><center><?php echo $data['nama'] ?></td>
                                    <td><center><?php echo $data['merk'] ?></td>
                                        <td><center><?php echo $data['nopol'] ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

