<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h4 class="h3 mb-0 text-gray-800"> &nbsp;MANAJEMEN AKUN</h4>
</div>

<!-- DataTales Example -->
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">FOTO</h6>
                </div>
                <div class="card-body">
                 <img src="akun/foto_admin/<?php echo $foto ?>" style="width: 300px;height: 300px;"> 
             </div>
         </div>
     </div>
     <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DATA ADMIN <a class="btn btn-primary btn-sm float-right" href="#ubah" data-toggle="modal">Ubah Data Admin</a></h6>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><center>Nama Lengkap</center></th>
                                <th><center>Username</center></th>
                                <th><center>Password</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><center><?php echo $nama ?></center></td>
                                <td><center><?php echo $username_admin ?></center></td>
                                <td><center><?php echo $password_admin ?></center></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<div class="modal fade" id="ubah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">FORM UBAH DATA</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="POST" enctype="multipart/form-data">
                    <input class="form-control" type="hidden" name="id_admin" value="<?php echo $id ?>">
                    <div class="form-group">
                      <label for="form-label">Nama Admin</label>
                      <input type="text" class="form-control" name="nama_admin" value="<?php echo $nama ?>" autocomplete="off">
                  </div>
                <div class="form-group">
                  <label for="form-label">Username</label>
                  <input type="text" value="<?php echo $username_admin ?>" class="form-control" name="username_admin" autocomplete="off">
              </div>
              <div class="form-group">
                  <label for="form-label">Password</label>
                  <input type="text" value="<?php echo $password_admin ?>" class="form-control" name="password_admin" autocomplete="off">
              </div>
              
              <div class="form-group">
                  <label for="form-label">Foto</label><br>
                  <input type="file" name="foto_admin">
                  <div class="d-flex justify-content-end">
                      <small id="name13" class="badge badge-default text-danger font-weight-medium bg-light-danger form-text">*Ukuran File Max 1 MB </small>
                  </div>
              </div>
              <div class="modal-footer">
                <button type="submit" name="edit" class="btn btn-success btn-sm">Simpan</button>
                <button class="btn btn-secondary btn-sm" type="button" data-dismiss="modal">Kembali</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>

<?php 


// Simpan menu
if (isset($_POST['edit'])) {

  $id_admin       = $_POST['id_admin'];
  $nama_admin           = $_POST['nama_admin'];
  $username_admin       = $_POST['username_admin'];
  $password_admin       = $_POST['password_admin'];
  $nama_gambar    = $_FILES['foto_admin']['name'];
  $tempat_gambar  = $_FILES['foto_admin']['tmp_name'];

  if (empty($nama_gambar)) {

    mysqli_query($koneksi, "UPDATE admin SET nama_admin='$nama_admin', username_admin='$username_admin', password_admin='$password_admin' WHERE id_admin='$id_admin'");

    echo "<script>alert('Data Kamu Berhasil Diubah')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=akun/index'></script>";
}else{

    $u=mysqli_query($koneksi,"SELECT * FROM admin WHERE id_admin='$id_admin'");
    $us=mysqli_fetch_array($u);

    file_exists("akun/foto_admin/".$us['foto_admin']);
    unlink("akun/foto_admin/".$us['foto_admin']);
    move_uploaded_file($tempat_gambar, "akun/foto/".$nama_gambar);

    $update_database =  mysqli_query($koneksi, "UPDATE admin SET nama_admin='$nama_admin', username_admin='$username_admin', password_admin='$password_admin', foto_admin='$nama_gambar' WHERE id_admin='$id_admin'");

    if($update_database){
       echo "<script>alert('Data Kamu Berhasil Diubah')</script>";
       echo "<meta http-equiv='refresh' content='0; url=?page=akun/index'></script>";
   }else{
      echo "<script>alert('Terjadi kesalahan coba ulangi kembali')</script>";
      echo "<meta http-equiv='refresh' content='0; url=?page=akun/index'></script>";
  }

}


}

?>