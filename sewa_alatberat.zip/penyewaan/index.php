<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h4 class="h3 mb-0 text-gray-800"> &nbsp;DATA PENYEWAAN</h4>
</div>

<!-- DataTales Example -->
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">FORM TAMBAH DATA</h6>
                </div>
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="form-group">
                            <label for="form-label">Nama Pelanggan</label>
                            <select class="form-control" name="id_pelanggan">
                                <option>---Pilih Nama Pelanggan---</option>
                                <?php 
                                $pelanggan = mysqli_query($koneksi, "SELECT * FROM pelanggan ORDER BY id_pelanggan DESC");
                                while ($datapelanggan = mysqli_fetch_array($pelanggan)) {
                                   ?>
                                   <option value="<?php echo $datapelanggan['id_pelanggan'] ?>"><?php echo $datapelanggan['nama_lengkap'] ?></option>
                               <?php } ?>

                           </select>
                       </div>
                       <div class="form-group">
                          <label for="form-label">Nama Alat Berat</label>
                          <select class="form-control" name="id_alatberat">
                            <option>---Pilih Nama Alat Berat---</option>
                            <?php 
                            $alat = mysqli_query($koneksi, "SELECT * FROM alat_berat ORDER BY id_alatberat DESC");
                            while ($dataalat = mysqli_fetch_array($alat)) {
                               ?>
                               <option value="<?php echo $dataalat['id_alatberat'] ?>"><?php echo $dataalat['nama'] ?></option>
                           <?php } ?>

                       </select>
                   </div>
                   <div class="form-group">
                      <label for="form-label">Harga</label>
                      <input type="text" maxlength="9" placeholder="Harga Sewa" class="form-control" name="harga" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">
                  </div>
                  <div class="form-group">
                      <label for="form-label">Tanggal Sewa</label>
                      <input type="date" class="form-control" name="tgl_sewa" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">
                  </div>
                  <div class="form-group">
                      <label for="form-label">Tanggal Pengembalian</label>
                      <input type="date" class="form-control" name="tgl_kembali" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">
                  </div>
                  <div class="button mt-5">
                    <button type="submit" name="simpan" class="btn btn-success btn-sm">Simpan</button>
                    <button type="reset" value="reset" class="btn btn-danger btn-sm">Batal</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="col-lg-8">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">DATA PENYEWAAN</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Pelanggan</th>
                            <th>Nama Alat Berat</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 

                        $no = 1;
                        $alat = mysqli_query($koneksi, "SELECT * FROM penyewaan JOIN pelanggan ON penyewaan.id_pelanggan=pelanggan.id_pelanggan JOIN alat_berat ON penyewaan.id_alatberat=alat_berat.id_alatberat ORDER BY penyewaan.id_sewa ASC");
                        while ($data = mysqli_fetch_array($alat)) {
                            ?>
                            <tr>
                                <td><center><?php echo $no++ ?></td>
                                    <td><center><?php echo $data['nama_lengkap'] ?></td>
                                        <td><center><?php echo $data['nama'] ?></td>
                                            <td><center>
                                                <?php
                                                if ($data['status']=='Sewa') {
                                                 echo "
                                                 <a href='#konfirmasiSelesai$data[id_sewa]' data-toggle='modal' style='text-decoration: none;'>
                                                 <span class='sewa'>Sewa</span>
                                                 </a>
                                                 ";
                                             }else if($data['status']=='Selesai'){
                                                 echo "
                                                 <span class='selesai'>Selesai</span>
                                                 ";
                                             }

                                             ?>
                                         </center>
                                         <td>
                                            <center>
                                                <div
                                                class="py-2 align-items-center">
                                                <div class="dropdown no-arrow">
                                                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-500"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                                aria-labelledby="dropdownMenuLink" style="margin-right: 12px;">
                                                <div class="dropdown-header">Aksi</div>
                                                <a href="#">
                                                    <a href="#ubah<?php echo $data['id_sewa'] ?>" data-toggle="modal" class="btn btn-info btn-icon-split btn-sm mb-1">
                                                        <span class="icon text-white-50">
                                                            <i class="fas fa-edit"></i>
                                                        </span>
                                                        <span class="text"> UBAH &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                    </a>
                                                    <a href="?page=penyewaan/detail&id=<?php echo base64_encode($data['id_sewa']) ?>" class="btn btn-warning btn-icon-split btn-sm">
                                                        <span class="icon text-white-50">
                                                            <i class="fas fa-info-circle"></i>
                                                        </span>
                                                        <span class="text"> DETAIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                    </a>
                                                    <div class="dropdown-divider"></div>
                                                    <a href="?page=penyewaan/hapus&id=<?php echo base64_encode($data['id_sewa']) ?>" class="btn btn-danger btn-icon-split btn-sm" onclick="return confirm('Yakin ingin menghapus data ini ?!');">
                                                        <span class="icon text-white-50">
                                                            <i class="fas fa-trash"></i>
                                                        </span>
                                                        <span class="text"> HAPUS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                    </a>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </center>
                            </td>
                        </tr>

                        <div class="modal fade" id="konfirmasiSelesai<?php echo $data['id_sewa'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <form action="" method="post">
                                    <input type="hidden" name="id_sewa" value="<?php echo $data['id_sewa'] ?>">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Yakin Ingin Mengkonfirmasi Selesai Untuk Penyewaan Ini?</h5>
                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">Pilih "Selesai" Untuk Melakukan Konfirmasi Status Penyewaan Ini</div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Kembali</button>
                                            <button type="submit" name="selesai" class="btn btn-primary">Selesai</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="modal fade" id="ubah<?php echo $data['id_sewa'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <form action="" method="post">
                                    <input type="hidden" name="id_sewa" value="<?php echo $data['id_sewa'] ?>">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">FORM UBAH DATA</h5>
                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="form-label">Nama Pelanggan</label>
                                                <select class="form-control" name="id_pelanggan">
                                                    <?php 
                                                    $mysql1 = mysqli_query($koneksi, "SELECT * FROM pelanggan");
                                                    while ($data1 = mysqli_fetch_array($mysql1)) {
                                                     ?>
                                                     <option value="<?php echo $data1['id_pelanggan'] ?>" <?php if ($data1['id_pelanggan']==$data['id_pelanggan']) {
                                                        echo "selected";
                                                    } ?>><?php echo $data1['nama_lengkap'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                          <label for="form-label">Nama Alat Berat</label>
                                          <select class="form-control" name="id_alatberat">
                                            <?php 
                                            $mysql2 = mysqli_query($koneksi, "SELECT * FROM alat_berat");
                                            while ($data2 = mysqli_fetch_array($mysql2)) {
                                             ?>
                                             <option value="<?php echo $data2['id_alatberat'] ?>" <?php if ($data2['id_alatberat']==$data['id_alatberat']) {
                                                echo "selected";
                                            } ?>><?php echo $data2['nama'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div> 

                                        <div class="form-group">
                                          <label for="form-label">Harga</label>
                                          <input type="text" maxlength="9"> class="form-control" name="harga" value="<?php echo $data['harga'] ?>" autocomplete="off">
                                      </div>
                                      <div class="form-group">
                                          <label for="form-label">Tanggal Sewa</label>
                                          <input type="date" class="form-control" name="tgl_sewa" value="<?php echo $data['tgl_sewa'] ?>" autocomplete="off">
                                      </div>
                                      <div class="form-group">
                                          <label for="form-label">Tanggal Pengembalian</label>
                                          <input type="date" class="form-control" name="tgl_kembali" value="<?php echo $data['tgl_kembali'] ?>" autocomplete="off">
                                      </div>
                                      <div class="modal-footer">
                                        <button type="submit" name="edit" class="btn btn-success btn-sm">Simpan</button>
                                        <button class="btn btn-secondary btn-sm" type="button" data-dismiss="modal">Kembali</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>


        <?php } ?>


    </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>

<?php 

if (isset($_POST['simpan'])) {
    date_default_timezone_set('Asia/Jakarta');
    $id_pelanggan = $_POST['id_pelanggan'];
    $id_alatberat = $_POST['id_alatberat'];
    $harga = $_POST['harga'];
    $tgl_sewa = $_POST['tgl_sewa'];
    $tgl_kembali = $_POST['tgl_kembali'];
    $jam_sewa = date('H:i:s');
    $jam_kembali = date('H:i:s');

    $mysqlcek = mysqli_query($koneksi, "SELECT * FROM penyewaan WHERE id_alatberat='$id_alatberat' AND status='Sewa'") or die (mysql_error($koneksi));
    if (mysqli_num_rows($mysqlcek)>0) {
        echo "<script>alert('Alat Berat Sedang Disewa, Harap Memilih Alat Berat Yang lain!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";
    }else{

        $input = mysqli_query($koneksi, "INSERT INTO penyewaan VALUES ('', '$id_pelanggan', '$id_alatberat', '$harga', '$tgl_sewa', '$tgl_kembali', '$jam_sewa', '$jam_kembali', 'Sewa')");

        if ($input) {
            echo "<script>alert('Data Penyewaan Berhasil Ditambah')</script>";
            echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";
        }else{
            echo "<script>alert('Terjadi kesalahan, coba ulangi kembali !')</script>";
            echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/tambah'></script>";
        }
    }

}

// END SIMPAN


// KOnfirmasi Selesai

if (isset($_POST['selesai'])) {

  $id_sewa = $_POST['id_sewa'];
  $update=mysqli_query($koneksi,"UPDATE penyewaan SET status='Selesai' WHERE id_sewa='$id_sewa'");

  if ($update) {

    echo "<script>alert('Status Penyewaan Selesai')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";

}else{

    echo "<script>alert('Terjadi kesalahan coba ulangi kembali')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";

}


}
// END

// Edit

if (isset($_POST['edit'])) {
  date_default_timezone_set('Asia/Jakarta');
  $id_sewa = $_POST['id_sewa'];
  $id_pelanggan = $_POST['id_pelanggan'];
  $id_alatberat = $_POST['id_alatberat'];
  $harga = $_POST['harga'];
  $tgl_sewa = $_POST['tgl_sewa'];
  $tgl_kembali = $_POST['tgl_kembali'];

  $updatedata = mysqli_query($koneksi, "UPDATE penyewaan SET id_pelanggan='$id_pelanggan', id_alatberat='$id_alatberat', harga='$harga', tgl_sewa='$tgl_sewa', tgl_kembali='$tgl_kembali' WHERE id_sewa='$id_sewa'");

  if($updatedata){
     echo "<script>alert('Data Penyewaan Berhasil Disimpan!')</script>";
     echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";

 }else{
    echo "<script>alert('Gagal Menyimpan, Coba Ulang Kembali!')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";
}

}

?>

