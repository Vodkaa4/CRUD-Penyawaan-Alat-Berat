<?php 

	$id = base64_decode($_GET['id']);
	$input1 = mysqli_query($koneksi, "DELETE FROM penyewaan WHERE id_sewa='$id'");
	
	if ($input1) {
		echo "<script>alert('Data Penyewaan Berhasil Dihapus')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";
	}else{
		echo "<script>alert('Terjadi kesalahan, coba ulangi kembali !')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=penyewaan/index'></script>";
	}

 ?>

