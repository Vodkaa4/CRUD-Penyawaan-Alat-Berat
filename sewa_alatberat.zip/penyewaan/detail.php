<?php 
$id = base64_decode($_GET['id']);
$mysql = mysqli_query($koneksi, "SELECT * FROM penyewaan JOIN pelanggan ON penyewaan.id_pelanggan=pelanggan.id_pelanggan JOIN alat_berat ON penyewaan.id_alatberat=alat_berat.id_alatberat WHERE penyewaan.id_sewa='$id'");
$data = mysqli_fetch_array($mysql); 

?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h4 class="h3 mb-0 text-gray-800"> &nbsp;DETAIL DATA PENYEWAAN</h4>
</div>

<!-- DataTales Example -->
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Gambar Alat Berat</h6>
                </div>
                <div class="card-body">
                 <img src="alat_berat/gambar_alat/<?php echo $data['gambar'] ?>" style="width: 300px;height: 300px;"> 
             </div>
         </div>
     </div>
     <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DATA PENYEWAAN <a class="btn btn-secondary btn-sm float-right" href="?page=penyewaan/index">Kembali</a></h6>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><center>Nama Lengkap</center></th>
                                <th><center>Nama Alat Berat</center></th>
                                <th><center>Harga</center></th>
                                <th><center>Tanggal/Jam Sewa</center></th>
                                <th><center>Tanggal/Jam Pengembalian</center></th>
                                <th><center>Status Sewa</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><center><?php echo $data['nama_lengkap'] ?></center></td>
                                <td><center><?php echo $data['nama'] ?></center></td>
                                <td><center><?php echo $data['harga'] ?></center></td>
                                <td><center><?php echo $data['tgl_sewa'] ?></center></td>
                                <td><center><?php echo $data['tgl_kembali'] ?></center></td>
                                <td><center><?php
                                            if ($data['status']=='Sewa') {
                                               echo "
                                               <span class='sewa'>Sewa</span>
                                               ";
                                           }else if($data['status']=='Selesai'){
                                               echo "
                                               <span class='selesai'>Selesai</span>
                                               ";
                                           }

                           ?></center></td>
                       </tr>
                   </tbody>
               </table>
           </div>
       </div>
   </div>
</div>
</div>
</div>

