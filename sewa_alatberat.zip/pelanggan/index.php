<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h4 class="h3 mb-0 text-gray-800"> &nbsp;DATA PELANGGAN</h4>
</div>

<!-- DataTales Example -->
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">FORM TAMBAH DATA</h6>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                          <label for="form-label">Nama Lengkap</label>
                          <input type="text" placeholder="Nama Lengkap" class="form-control" name="nama_lengkap" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">
                      </div>
                      <div class="form-group">
                          <label for="form-label">Jenis Kelamin</label>
                          <select class="form-control" name="jenis_kelamin">
                              <option value="Laki-Laki">Laki-Laki</option>
                              <option value="Perempuan">Perempuan</option>
                          </select>
                      </div>
                      <div class="form-group">
                          <label for="form-label">No HP</label>
                          <input type="text" placeholder="No Hp" class="form-control" name="no_hp" required oninvalid="this.setCustomValidity('Kolom ini tidak boleh kosong')" oninput="setCustomValidity('')" autocomplete="off">
                      </div>
                      <div class="form-group">
                          <label for="form-label">Alamat</label>
                          <textarea class="form-control" rows="3" name="alamat"></textarea>
                      </div>
                      <div class="form-group">
                          <label for="form-label">Foto</label>
                          <input type="file" name="foto">
                          <div class="d-flex justify-content-end">
                              <small id="name13" class="badge badge-default text-danger font-weight-medium bg-light-danger form-text">*Ukuran File Max 1 MB </small>
                          </div>
                      </div>
                      <div class="button mt-5">
                        <button type="submit" name="simpan" class="btn btn-success btn-sm">Simpan</button>
                        <button type="reset" value="reset" class="btn btn-danger btn-sm">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DATA PELANGGAN</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Lengkap</th>
                                <th>No HP</th>
                                <th>Alamat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 

                            $no = 1;
                            $alat = mysqli_query($koneksi, "SELECT * FROM pelanggan");
                            while ($data = mysqli_fetch_array($alat)) {
                                ?>
                                <tr>
                                    <td><center><?php echo $no++ ?></td>
                                        <td><center><?php echo $data['nama_lengkap'] ?></td>
                                            <td><center><?php echo $data['no_hp'] ?></td>
                                                <td><center><?php echo $data['alamat'] ?></td>
                                                    <td>
                                                        <center>
                                                            <div
                                                            class="py-2 align-items-center">
                                                            <div class="dropdown no-arrow">
                                                                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-500"></i>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                                            aria-labelledby="dropdownMenuLink" style="margin-right: 12px;">
                                                            <div class="dropdown-header">Aksi</div>
                                                            <a href="#">
                                                                <a href="#ubah<?php echo $data['id_pelanggan'] ?>" data-toggle="modal" class="btn btn-info btn-icon-split btn-sm mb-1">
                                                                    <span class="icon text-white-50">
                                                                        <i class="fas fa-edit"></i>
                                                                    </span>
                                                                    <span class="text"> UBAH &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                                </a>
                                                                <a href="?page=pelanggan/detail&id=<?php echo base64_encode($data['id_pelanggan']) ?>" class="btn btn-warning btn-icon-split btn-sm">
                                                                    <span class="icon text-white-50">
                                                                        <i class="fas fa-info-circle"></i>
                                                                    </span>
                                                                    <span class="text"> DETAIL&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                                </a>
                                                                <div class="dropdown-divider"></div>
                                                                <a href="?page=pelanggan/hapus&id=<?php echo base64_encode($data['id_pelanggan']) ?>" class="btn btn-danger btn-icon-split btn-sm" onclick="return confirm('Yakin ingin menghapus data ini ?!');">
                                                                    <span class="icon text-white-50">
                                                                        <i class="fas fa-trash"></i>
                                                                    </span>
                                                                    <span class="text"> HAPUS&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                                </a>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </center>
                                        </td>
                                    </tr>

                                    <div class="modal fade" id="ubah<?php echo $data['id_pelanggan'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                        aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">FORM UBAH DATA</h5>
                                                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="" method="POST" enctype="multipart/form-data">
                                                        <input type="hidden" name="id_pelanggan" value="<?php echo $data['id_pelanggan'] ?>">
                                                        <div class="form-group">
                                                          <label for="form-label">Nama Lengkap</label>
                                                          <input type="text" placeholder="Nama Lengkap" class="form-control" name="nama_lengkap" value="<?php echo $data['nama_lengkap'] ?>" autocomplete="off">
                                                      </div>
                                                      <div class="form-group">
                                                          <label for="form-label">Jenis Kelamin</label>
                                                          <select class="form-control" name="jenis_kelamin">
                                                              <option value="Laki-Laki" <?php if ($data['jenis_kelamin']=='Laki-Laki') {
                                                                    echo "selected";
                                                                  }?>>Laki-Laki</option>
                                                                  <option value="Perempuan" <?php if ($data['jenis_kelamin']=='Perempuan') {
                                                                    echo "selected";
                                                                  }?>>Perempuan</option>
                                                          </select>
                                                      </div>
                                                      <div class="form-group">
                                                          <label for="form-label">No HP</label>
                                                          <input type="text" placeholder="No Hp" value="<?php echo $data['no_hp'] ?>" class="form-control" name="no_hp" value="" autocomplete="off">
                                                      </div>
                                                      <div class="form-group">
                                                          <label for="form-label">Alamat</label>
                                                          <textarea class="form-control" rows="3" name="alamat"><?php echo $data['alamat'] ?></textarea>
                                                      </div>
                                                      <div class="form-group">
                                                          <label for="form-label">Foto</label><br>
                                                          <input type="file" name="foto">
                                                          <div class="d-flex justify-content-end">
                                                              <small id="name13" class="badge badge-default text-danger font-weight-medium bg-light-danger form-text">*Ukuran File Max 1 MB </small>
                                                          </div>
                                                      </div>
                                                      <div class="modal-footer">
                                                        <button type="submit" name="edit" class="btn btn-success btn-sm">Simpan</button>
                                                        <button class="btn btn-secondary btn-sm" type="button" data-dismiss="modal">Kembali</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            <?php } ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php 

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_lengkap'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];
    $namaFoto = $_FILES['foto']['name'];
    $tempatFoto = $_FILES['foto']['tmp_name'];
    $ekstensi =  array('png','jpg','jpeg','gif');
    $ext = pathinfo($namaFoto, PATHINFO_EXTENSION);
    $extension = strtolower($ext);

  //Pembatasan kapasitas foto
    $ukuranFoto = $_FILES['foto']['size'];

    $max = 1000000;
    //1 MB

    $min = 1000;
    //1kb

    $mysqlcek = mysqli_query($koneksi, "SELECT * FROM pelanggan WHERE nama_lengkap='$nama'") or die (mysql_error($koneksi));
    if (mysqli_num_rows($mysqlcek)>0) {
        echo "<script>alert('Nama Pelanggan Sudah Ada, Isilah dengan nama brand lainnya!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
    }else{

      if (empty($namaFoto)) {
        mysqli_query($koneksi, "INSERT INTO pelanggan VALUES ('', '$nama', '$jenis_kelamin', '$no_hp', '$alamat', '');");

        echo "<script>alert('Data Pelanggan Berhasil Disimpan!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
    }else{

        if ( $ukuranFoto >= $min ) {
          if ( $ukuranFoto <= $max ) {
            if(!in_array($ext, $ekstensi)) {
                echo "<script>alert('Gagal Menyimpan, file wajib JPG, JPEG, PNG & GIF!')</script>";
                echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
            }else{
              $rename_nama_file = date('YmdHis');
              $nama_file_baru  = $rename_nama_file.'.'.$extension;
              $simpanFoto = move_uploaded_file($tempatFoto, "pelanggan/foto_pelanggan/" . $nama_file_baru); 
              if ($simpanFoto) {
                mysqli_query($koneksi, "INSERT INTO pelanggan VALUES ('', '$nama', '$jenis_kelamin', '$no_hp', '$alamat', '$nama_file_baru');");
                echo "<script>alert('Data Pelanggan Berhasil Disimpan!')</script>";
                echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";

            }else{
                echo "<script>alert('Gagal Menyimpan, Coba Ulang Kembali!')</script>";
                echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
            }
        }
    }else{
        echo "<script>alert('Gagal Menyimpan, Ukuran file Terlalu Besar!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
    }

} elseif ( $ukuranFoto < $min ) {
    echo "<script>alert('Gagal Menyimpan, Ukuran file Terlalu Kecil!')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
}

}

}

}

// END SIMPAN

if (isset($_POST['edit'])) {
  $id_pelanggan = $_POST['id_pelanggan'];
  $nama = $_POST['nama_lengkap'];
  $jenis_kelamin = $_POST['jenis_kelamin'];
  $no_hp = $_POST['no_hp'];
  $alamat = $_POST['alamat'];
  $namaFoto = $_FILES['foto']['name'];
  $tempatFoto = $_FILES['foto']['tmp_name'];
  $ekstensi =  array('png','jpg','jpeg','gif');
  $ext = pathinfo($namaFoto, PATHINFO_EXTENSION);
  $extension = strtolower($ext);

  if (empty($namaFoto)) {
    mysqli_query($koneksi, "UPDATE pelanggan SET nama_lengkap='$nama', jenis_kelamin='$jenis_kelamin', no_hp='$no_hp', alamat='$alamat' WHERE id_pelanggan='$id_pelanggan'");

    echo "<script>alert('Data Pelanggan Berhasil Disimpan!')</script>";
    echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";

  }else{

    if(!in_array($ext, $ekstensi)) {
       echo "<script>alert('Gagal Menyimpan, file wajib JPG, JPEG, PNG & GIF!')</script>";
       echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
    }else{

      $rename_nama_file = date('YmdHis');
      $nama_file_baru  = $rename_nama_file.'.'.$extension;

      $u=mysqli_query($koneksi,"SELECT * FROM pelanggan WHERE id_pelanggan='$id_pelanggan'");
      $us=mysqli_fetch_array($u);
      file_exists("pelanggan/foto_pelanggan/".$us['foto']);
      unlink("pelanggan/foto_pelanggan/".$us['foto']);
      move_uploaded_file($tempatFoto, "pelanggan/foto_pelanggan/".$nama_file_baru);

      $updatedata = mysqli_query($koneksi, "UPDATE pelanggan SET nama_lengkap='$nama', jenis_kelamin='$jenis_kelamin', no_hp='$no_hp', alamat='$alamat', foto='$nama_file_baru' WHERE id_pelanggan='$id_pelanggan'");

      if($updatedata){
         echo "<script>alert('Data Pelanggan Berhasil Disimpan!')</script>";
         echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";

     }else{
        echo "<script>alert('Gagal Menyimpan, Coba Ulang Kembali!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
    }

}

}



}
?>

