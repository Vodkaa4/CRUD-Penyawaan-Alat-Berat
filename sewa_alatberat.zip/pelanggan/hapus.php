<?php 
    $id = base64_decode($_GET['id']);
    $my = mysqli_query($koneksi, "SELECT * FROM pelanggan WHERE id_pelanggan='$id'");
    $data = mysqli_fetch_array($my);
    $foto = $data['foto'];
	if (file_exists("pelanggan/foto_pelanggan/$foto")){
        unlink("pelanggan/foto_pelanggan/$foto");
        echo "<script>alert('Data Pelanggan Berhasil Dihapus!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
    }else{
        echo "<script>alert('Terjadi Kesalahan Coba Ulangi!')</script>";
        echo "<meta http-equiv='refresh' content='0; url=?page=pelanggan/index'></script>";
    }

    $my2 = mysqli_query($koneksi, "DELETE FROM pelanggan WHERE id_pelanggan='$id'");
    
 ?>