<?php 
$id = base64_decode($_GET['id']);
$mysql = mysqli_query($koneksi, "SELECT * FROM pelanggan WHERE id_pelanggan='$id'");
$data = mysqli_fetch_array($mysql); 

?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h4 class="h3 mb-0 text-gray-800"> &nbsp;DETAIL DATA PELANGGAN</h4>
</div>

<!-- DataTales Example -->
<div class="col-lg-12">
    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">FOTO KTP PELANGGAN</h6>
                </div>
                <div class="card-body">
                   <img src="pelanggan/foto_pelanggan/<?php echo $data['foto'] ?>" style="width: 300px;height: 300px;"> 
               </div>
           </div>
       </div>
       <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DATA PELANGGAN <a class="btn btn-secondary btn-sm float-right" href="?page=pelanggan/index">Kembali</a></h6>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th><center>Nama Lengkap</center></th>
                                <th><center>Jenis Kelamin</center></th>
                                <th><center>No HP</center></th>
                                <th><center>Alamat</center></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><center><?php echo $data['nama'] ?></td>
                                    <td><center><?php echo $data['jenis_kelamin'] ?></td>
                                        <td><center><?php echo $data['no_hp'] ?></td>
                                            <td><center><?php echo $data['alamat'] ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

