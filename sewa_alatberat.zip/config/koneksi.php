<?php 
error_reporting(0);
// konfigurasi Database
$server = "localhost";
$username = "root";
$password = "";
$database = "db_sewa_alatberat";
$koneksi = mysqli_connect("$server", "$username", "$password");
$select_db = mysqli_select_db($koneksi, $database);

if(!$select_db){
	echo ("Koneksi Gagal");
}

?>